Click the start button on each client0 and client1 GUI will show all the demo activities. Req #13
Then you can use the GUI to creat and send more request, upload file, query result.

All the sendt and receive message are shown in console(including log file list and results queried).

The folder named toSend in ThisWindow/ThatWindow folder is the default directory where stores the client side files.
The folder named ReceivedFiles in Repository folder is the directory where files and log are stored. - Req #7 #8

The Mixed Thread ID(TID) in TestHarness console and ReceivedFiles folder shows Test Requests are processed concurrently - Req #4.

planAndExecute.docx is the answer for Req #14